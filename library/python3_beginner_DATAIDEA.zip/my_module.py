# this is my_module.py

first_name = 'Viola'
last_name = 'Akullu'

def add(number1, number2):
    return number1 + number2

def multiply(number1, number2):
    return number1 * number2